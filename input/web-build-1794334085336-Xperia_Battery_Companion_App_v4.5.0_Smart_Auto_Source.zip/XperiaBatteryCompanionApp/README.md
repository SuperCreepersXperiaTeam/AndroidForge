# Xperia Battery Companion App 4.5.0 — Creeper Originals

**Autor:** SuperCreeper'sXperiaTeam  
**Aplicación:** Android nativa, interfaz en español, icono Creeper y widget.

## Integración con el módulo Magisk v4.5.0
La aplicación lee el historial CSV de `/data/local/tmp/xperia_battery_companion/battery_log.csv` y consulta el perfil guardado en `/data/local/tmp/xperia_battery_companion/optimizer.conf`.

La sección **Optimizador de batería** muestra el perfil activo y permite aplicar directamente:
- `adaptive` — ahorro automático con pantalla apagada y equilibrado al usar el teléfono.
- `balanced` — restaura el máximo de CPU original detectado.
- `battery` — límite de CPU del 75% del máximo original, si el kernel lo permite.
- `ultra` — límite de CPU del 60% del máximo original, si el kernel lo permite.
- `performance` — restaura el máximo original y solicita governor `performance` solo si está disponible.

Los cambios se ejecutan mediante `su` y el helper del módulo Magisk. La app necesita que el módulo **Xperia Battery Companion v4.5.0** esté instalado y que el usuario conceda root desde Magisk. Si el módulo no está activo, la app informa que no pudo aplicar el perfil.

## Compilar
Requisitos: Android Studio, JDK 17 y Android SDK 34.
1. Extrae el ZIP y abre `XperiaBatteryCompanionApp` en Android Studio.
2. Espera a que Gradle sincronice.
3. Selecciona **Build > Build APK(s)**.
4. Instala el APK generado en `app/build/outputs/apk/debug/`.

## Notas y seguridad
- Este paquete es **código fuente**, no un APK compilado.
- No se pudo compilar ni probar en un Xperia físico en este entorno porque no hay Android SDK/Gradle disponible.
- El cambio de perfil requiere root y el módulo v4.5.0. El módulo detecta controles cpufreq compatibles; los valores no disponibles se omiten.
- Los límites 75%/60% son experimentales y pueden reducir el rendimiento. Si notas lentitud, calentamiento o inestabilidad, vuelve a `balanced`.
- La aplicación no desactiva protecciones del BMS ni promete recuperar una autonomía específica.
- Se conserva el historial CSV y el widget existente.


Smart Auto: el módulo selecciona perfiles según pantalla, llamada/reproducción,
app en primer plano y carga del sistema. Desde la app se pueden proteger paquetes
para mantenerlos en balanced. También puedes declarar apps ligeras, que solo usan
battery cuando la carga del sistema es baja. Las apps no reconocidas nunca reciben Ultra.
