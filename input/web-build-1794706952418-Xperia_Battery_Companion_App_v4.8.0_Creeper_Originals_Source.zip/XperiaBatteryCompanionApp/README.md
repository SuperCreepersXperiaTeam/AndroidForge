# Xperia Battery Companion v4.8.0 — Creeper Originals

- Magisk module + native Android app source.
- Faster battery loop (about 5 s) with CSV writes throttled to 10 s.
- Wake-gap RAW resynchronization uses a stable 3-reading window and bounded correction; no voltage-only percentage correction.
- Widget percentage reads the live module state file first, not the last arbitrary CSV event (prevents a warning row such as 15% from pinning the widget).
- Autonomy estimate uses recent valid sample rows and reports insufficient/unstable data rather than inventing a duration.
- Smart/Eco cooperate additively with Android Battery Saver; no feature is disabled solely because Battery Saver is active.
- Eco 2.0 applies a reversible 65% CPU maximum only when cpufreq nodes are writable, and yields to calls, active media and protected apps. Other profiles: Battery 85%, Ultra 75%, Balanced/Performance restore original maximum. Governors are preserved.
- Voltage controls are diagnostic-only. No battery-cell voltage, charge-current, BMS, thermal-protection, GPU voltage or undocumented undervolt values are written.
- Existing six-column CSV and filter state are preserved.

## Validation
Shell syntax, XML parsing, ZIP integrity and Java source structural checks are performed before release. APK compilation and on-device testing require Android SDK/Gradle and the target Xperia; they are not claimed unless actually executed.
