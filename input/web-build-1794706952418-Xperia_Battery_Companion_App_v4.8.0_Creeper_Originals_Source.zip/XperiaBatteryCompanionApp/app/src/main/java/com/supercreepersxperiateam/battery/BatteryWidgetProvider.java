package com.supercreepersxperiateam.battery;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class BatteryWidgetProvider extends AppWidgetProvider {
    private static final String BASE="/data/local/tmp/xperia_battery_companion";
    private static final String LOG=BASE+"/battery_log.csv";
    @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids){ for(int id:ids) updateOne(c,m,id); }
    @Override public void onReceive(Context context, Intent intent){
        super.onReceive(context,intent);
        String action=intent==null?"":intent.getAction();
        if(Intent.ACTION_SCREEN_ON.equals(action)||Intent.ACTION_USER_PRESENT.equals(action)||
           Intent.ACTION_POWER_CONNECTED.equals(action)||Intent.ACTION_POWER_DISCONNECTED.equals(action)) refreshAll(context);
    }
    public static void refreshAll(Context c){ AppWidgetManager m=AppWidgetManager.getInstance(c); int[] ids=m.getAppWidgetIds(new ComponentName(c,BatteryWidgetProvider.class)); for(int id:ids) updateOne(c,m,id); }
    private static void updateOne(Context c, AppWidgetManager m, int id){
        RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.battery_widget);
        String dump=rootRead("pct=$(cat "+BASE+"/state 2>/dev/null); echo STATE=$pct; tail -n 1200 "+LOG+" 2>/dev/null");
        String pct="—", status="Esperando módulo", remaining="Autonomía calculándose…";
        List<long[]> samples=new ArrayList<>();
        String[] rows=dump.split("\\r?\\n");
        for(String row:rows){
            if(row.startsWith("STATE=")){String x=row.substring(6).trim(); if(x.matches("[0-9]{1,3}")){int n=Integer.parseInt(x);if(n>=1&&n<=100)pct=String.valueOf(n);} continue;}
            String[] a=row.split(",",6); if(a.length<6||a[0].equals("fecha_hora"))continue;
            try{int p=Integer.parseInt(a[1].trim());long ts=timestamp(a[0].trim());if(p>=1&&p<=100&&ts>0&&a[5].trim().startsWith("muestra"))samples.add(new long[]{ts,p});status="Última muestra: "+a[0].trim();}catch(Exception ignored){}
        }
        if(!samples.isEmpty()){
            long[] last=samples.get(samples.size()-1); if("—".equals(pct))pct=String.valueOf(last[1]);
            int first=samples.size()-1; while(first>0&&last[0]-samples.get(first-1)[0]<=15*60*1000L)first--;
            long[] begin=samples.get(first);long elapsed=last[0]-begin[0];int drop=(int)(begin[1]-last[1]);
            if(elapsed>=30*60*1000L&&drop>=2&&last[1]>0){double rate=drop/(elapsed/3600000.0);if(rate>0&&rate<=8){long mins=Math.round(last[1]/rate*60.0);if(mins<=10080)remaining=(mins/60)+" h "+(mins%60)+" min aprox.";else remaining="Reuniendo muestras recientes";}else remaining="Reuniendo muestras recientes";}
        }else if(dump.isEmpty())status="Concede root a la aplicación";
        if("—".equals(pct))status="Esperando lectura RAW del módulo";
        v.setTextViewText(R.id.widget_percent,"—".equals(pct)?"—%":pct+"%");v.setTextViewText(R.id.widget_remaining,remaining);v.setTextViewText(R.id.widget_status,status);
        Intent launch=new Intent(c,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(c,0,launch,PendingIntent.FLAG_UPDATE_CURRENT|(android.os.Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));
        v.setOnClickPendingIntent(R.id.widget_percent,pi);v.setOnClickPendingIntent(R.id.widget_status,pi);v.setOnClickPendingIntent(R.id.widget_brand,pi);m.updateAppWidget(id,v);
    }
    private static String rootRead(String cmd){StringBuilder b=new StringBuilder();try{java.lang.Process p=Runtime.getRuntime().exec(new String[]{"su","-c",cmd});BufferedReader r=new BufferedReader(new InputStreamReader(p.getInputStream()));String l;while((l=r.readLine())!=null)b.append(l).append('\n');p.waitFor();}catch(Exception ignored){}return b.toString();}
    private static long timestamp(String s){try{SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US);f.setLenient(false);return f.parse(s).getTime();}catch(Exception e){return -1;}}
}
