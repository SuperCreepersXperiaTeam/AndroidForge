package com.supercreepersxperiateam.battery;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(16,21,29), panel = Color.rgb(27,35,46),
        muted = Color.rgb(166,180,196), green = Color.rgb(114,214,160), white = Color.WHITE;
    private LinearLayout root, content;
    private static final String BASE = "/data/local/tmp/xperia_battery_companion";
    private static final String LOG = BASE + "/battery_log.csv";
    private static final String CONF = BASE + "/optimizer.conf";
    private static final String OPT = "/data/adb/modules/xperia_battery_companion/system/bin/xperia-battery-optimizer";

    @Override public void onCreate(Bundle state) { super.onCreate(state); build(); refresh(); }

    private void build() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(bg);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20),dp(22),dp(20),dp(24)); scroll.addView(root);
        root.addView(text("SUPER CREEPER'S XPERIA TEAM",12,green,true));
        TextView title=text("Batería Xperia",29,white,true);
        LinearLayout.LayoutParams tp=params(-1,-2); tp.topMargin=dp(7); root.addView(title,tp);
        root.addView(text("Xperia Battery Companion · App 4.4.0",14,muted,false),params(-1,-2));
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams cp=params(-1,-2); cp.topMargin=dp(16); root.addView(content,cp);
        Button refresh = button("Actualizar estado"); refresh.setOnClickListener(v -> refresh());
        LinearLayout.LayoutParams rp=params(-1,dp(50)); rp.topMargin=dp(12); root.addView(refresh,rp);
        Button notify = button("Probar notificación");
        LinearLayout.LayoutParams np=params(-1,dp(50)); np.topMargin=dp(10); root.addView(notify,np);
        notify.setOnClickListener(v -> testNotification());
        TextView foot=text("La autonomía es una estimación. Los perfiles avanzados solo cambian controles CPU que el kernel exponga como compatibles; no modifican las protecciones físicas del BMS.",12,muted,false);
        LinearLayout.LayoutParams fp=params(-1,-2); fp.topMargin=dp(18); root.addView(foot,fp);
        setContentView(scroll);
    }

    private void refresh() {
        content.removeAllViews();
        addOptimizerPanel();
        String dump = su("cat " + LOG + " 2>/dev/null");
        String[] rows = dump.trim().split("\\r?\\n");
        String[] cols = rows.length > 1 ? rows[rows.length-1].split(",") : new String[0];
        String percent="—", voltage="—", raw="—";
        if(cols.length>=4){percent=cols[1];raw=cols[2];voltage=cols[3];}
        card("CARGA ESTIMADA", percent.equals("—")?"Sin datos":percent+"%", "Lectura registrada por el módulo", green);
        rowCards("AUTONOMÍA RESTANTE",estimate(rows),"VOLTAJE BMS",voltage.equals("—")?"—":voltage+" mV");
        card("DIAGNÓSTICO",rows.length>2?"Registro disponible":"Esperando muestras",
            "Muestras guardadas: "+Math.max(0,rows.length-1)+" · RAW: "+raw,white);
        TextView hist=text("Últimas muestras",18,white,true);
        LinearLayout.LayoutParams hp=params(-1,-2); hp.topMargin=dp(8); content.addView(hist,hp);
        int shown=0;
        for(int i=rows.length-1;i>=1 && shown<6;i--){
            if(rows[i].trim().isEmpty()) continue;
            content.addView(lineCard(rows[i])); shown++;
        }
        if(shown==0) content.addView(lineCard("Todavía no hay suficientes datos. Comprueba que el módulo Magisk esté activo."));
        BatteryWidgetProvider.refreshAll(this);
    }

    private void addOptimizerPanel() {
        LinearLayout section=box();
        section.addView(text("OPTIMIZADOR DE BATERÍA",12,green,true));
        String profile=readProfile();
        section.addView(text("Perfil activo: "+profileLabel(profile),21,white,true),topMargin(params(-1,-2),dp(7)));
        section.addView(text("Selecciona un perfil. El cambio se aplica inmediatamente y el módulo lo conserva tras reiniciar.",12,muted,false),topMargin(params(-1,-2),dp(5)));
        addProfileButton(section,"Adaptativo","adaptive","Ahorra con pantalla apagada y vuelve a equilibrado al usar el teléfono.");
        addProfileButton(section,"Equilibrado","balanced","Restaura el límite máximo original detectado al iniciar.");
        addProfileButton(section,"Autonomía","battery","Limita el máximo de CPU al 75% del valor original, si es compatible.");
        addProfileButton(section,"Ahorro extremo","ultra","Limita el máximo de CPU al 60% del valor original, si es compatible.");
        addProfileButton(section,"Rendimiento","performance","Restaura el máximo original; usa governor performance solo si existe.");
        String last=su("tail -n 1 "+BASE+"/optimizer.log 2>/dev/null").trim();
        TextView diag=text(last.isEmpty()?"Diagnóstico CPU: esperando aplicación de perfil.":"CPU: "+last,11,muted,false);
        section.addView(diag,topMargin(params(-1,-2),dp(8)));
        content.addView(section);
    }

    private void addProfileButton(LinearLayout parent,String title,String id,String detail) {
        Button b=button(title+"  ·  "+id);
        LinearLayout.LayoutParams bp=params(-1,dp(46)); bp.topMargin=dp(9); parent.addView(b,bp);
        TextView d=text(detail,11,muted,false); parent.addView(d,topMargin(params(-1,-2),dp(3)));
        b.setOnClickListener(v -> {
            b.setEnabled(false);
String cmd="OPT="+OPT+"; [ -x \"$OPT\" ] || OPT=/data/adb/modules_update/xperia_battery_companion/system/bin/xperia-battery-optimizer; [ -x \"$OPT\" ] || { echo PROFILE_ERROR_NO_MODULE; exit 3; }; \"$OPT\" set "+id+" && \"$OPT\" apply && echo PROFILE_APPLIED";
            String result=su(cmd);
            b.setEnabled(true);
            if(result.trim().isEmpty()) result="Comando enviado. Comprueba el perfil activo y el diagnóstico.";
            refresh();
            android.widget.Toast.makeText(this,result.contains("PROFILE_APPLIED")?"Perfil "+title+" aplicado":"No se pudo aplicar el perfil. Comprueba Magisk/root y que v4.4.0 esté instalado.",android.widget.Toast.LENGTH_LONG).show();
        });
    }

    private String readProfile() {
        String p=su("cat "+CONF+" 2>/dev/null").trim();
        if(p.equals("adaptive")||p.equals("balanced")||p.equals("battery")||p.equals("ultra")||p.equals("performance")) return p;
        return "adaptive";
    }
    private String profileLabel(String p) {
        if("balanced".equals(p))return "Equilibrado";
        if("battery".equals(p))return "Autonomía";
        if("ultra".equals(p))return "Ahorro extremo";
        if("performance".equals(p))return "Rendimiento";
        return "Adaptativo";
    }
    private LinearLayout.LayoutParams topMargin(LinearLayout.LayoutParams p,int m){p.topMargin=m;return p;}

    private String estimate(String[] rows) {
        try {
            java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss",java.util.Locale.US);
            f.setLenient(false); f.setTimeZone(java.util.TimeZone.getDefault());
            java.util.ArrayList<long[]> samples=new java.util.ArrayList<>();
            for(int i=1;i<rows.length;i++){
                String[] c=rows[i].split(",");
                if(c.length<6||!c[5].trim().equals("muestra"))continue;
                long t=f.parse(c[0].trim()).getTime();int p=Integer.parseInt(c[1].trim());
                if(p<1||p>100)continue;
                if(!samples.isEmpty()&&t<=samples.get(samples.size()-1)[0])continue;
                samples.add(new long[]{t,p});
            }
            if(samples.size()<2)return "Aún calculando";
            long[] last=samples.get(samples.size()-1);int first=samples.size()-1;
            while(first>0&&last[0]-samples.get(first-1)[0]<=15*60*1000L)first--;
            long[] start=samples.get(first);long elapsed=last[0]-start[0];
            int drop=(int)(start[1]-last[1]);
            if(elapsed<30*60*1000L||drop<2||last[1]<=0)return "Aún calculando";
            double rate=drop/(elapsed/3600000.0);
            if(rate<=0||rate>10)return "Estimación inestable";
            long mins=Math.round(last[1]/rate*60.0);
            if(mins>7L*24*60)return "Estimación inestable";
            return "~"+(mins/60)+" h "+(mins%60)+" min";
        }catch(Exception e){return "Aún calculando";}
    }

    private void card(String heading,String value,String detail,int valueColor){
        LinearLayout box=box(); box.addView(text(heading,11,muted,true));
        box.addView(text(value,27,valueColor,true),topMargin(params(-1,-2),dp(6)));
        box.addView(text(detail,13,muted,false),topMargin(params(-1,-2),dp(4))); content.addView(box);
    }
    private void rowCards(String h1,String v1,String h2,String v2){
        LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout a=smallCard(h1,v1),b=smallCard(h2,v2);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.rightMargin=dp(6);r.addView(a,p);
        LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(0,-2,1);q.leftMargin=dp(6);r.addView(b,q);content.addView(r);
    }
    private LinearLayout smallCard(String h,String v){LinearLayout b=box();b.addView(text(h,10,muted,true));b.addView(text(v,18,white,true),topMargin(params(-1,-2),dp(8)));return b;}
    private View lineCard(String s){LinearLayout b=box();b.addView(text(s.replace(",","   ·   "),12,white,false));return b;}
    private LinearLayout box(){LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);b.setPadding(dp(16),dp(15),dp(16),dp(15));b.setBackgroundColor(panel);LinearLayout.LayoutParams p=params(-1,-2);p.topMargin=dp(10);b.setLayoutParams(p);return b;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(bg);b.setTextSize(13);b.setAllCaps(false);b.setTypeface(null,Typeface.BOLD);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(green));return b;}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    private LinearLayout.LayoutParams params(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    private String su(String command){
        StringBuilder out=new StringBuilder();
        try{
            Process p=Runtime.getRuntime().exec(new String[]{"su","-c",command});
            BufferedReader r=new BufferedReader(new InputStreamReader(p.getInputStream()));
            String l;while((l=r.readLine())!=null)out.append(l).append('\n');
            p.waitFor();
        }catch(Exception e){return "";}
        return out.toString();
    }
    private void testNotification(){
        String id="xperia_battery_status";
        NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel(id,"Batería Xperia",NotificationManager.IMPORTANCE_DEFAULT));
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,id):new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_lock_idle_low_battery).setContentTitle("Batería Xperia")
            .setContentText("Las alertas de la aplicación funcionan correctamente.")
            .setAutoCancel(true);nm.notify(1201,b.build());
    }
}
