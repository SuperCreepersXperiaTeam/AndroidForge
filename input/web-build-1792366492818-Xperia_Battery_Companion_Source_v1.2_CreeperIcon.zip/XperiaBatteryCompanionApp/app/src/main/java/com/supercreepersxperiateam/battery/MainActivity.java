package com.supercreepersxperiateam.battery;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(16,21,29), panel = Color.rgb(27,35,46), muted = Color.rgb(166,180,196), green = Color.rgb(114,214,160), white = Color.WHITE;
    private LinearLayout root, content;
    private static final String LOG = "/data/local/tmp/xperia_battery_companion/battery_log.csv";

    @Override public void onCreate(Bundle state) { super.onCreate(state); build(); refresh(); }
    private void build() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(bg);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(20),dp(22),dp(20),dp(24)); scroll.addView(root);
        TextView brand = text("SUPER CREEPER'S XPERIA TEAM",12,green,true); root.addView(brand);
        TextView title = text("Batería Xperia",29,white,true); LinearLayout.LayoutParams tp = params(-1,-2); tp.topMargin=dp(7); root.addView(title,tp);
        root.addView(text("Estado, autonomía e historial",14,muted,false), params(-1,-2));
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); LinearLayout.LayoutParams cp=params(-1,-2); cp.topMargin=dp(20); root.addView(content,cp);
        Button refresh = button("Actualizar estado"); refresh.setOnClickListener(v -> refresh()); root.addView(refresh, params(-1,dp(50)));
        Button notify = button("Probar notificación"); LinearLayout.LayoutParams np=params(-1,dp(50)); np.topMargin=dp(10); root.addView(notify,np); notify.setOnClickListener(v -> testNotification());
        TextView foot=text("Los cálculos dependen del registro y de la estimación experimental raw/100. No es una calibración oficial.",12,muted,false); LinearLayout.LayoutParams fp=params(-1,-2); fp.topMargin=dp(18); root.addView(foot,fp);
        setContentView(scroll);
    }
    private void refresh() {
        content.removeAllViews();
        String dump = su("cat " + LOG + " 2>/dev/null");
        String[] rows = dump.trim().split("\\r?\\n");
        String last = rows.length > 1 ? rows[rows.length-1] : "";
        String[] cols = last.split(",");
        String percent = "—", voltage="—", raw="—", remaining="Aún calculando";
        if(cols.length >= 4) { percent=cols.length>1?cols[1]:"—"; raw=cols.length>2?cols[2]:"—"; voltage=cols.length>3?cols[3]:"—"; }
        for(int i=rows.length-1;i>=1;i--) { String[] c=rows[i].split(","); if(c.length>=6 && !c[5].trim().isEmpty() && !c[5].equalsIgnoreCase("remaining_minutes")) { try { int m=Integer.parseInt(c[5].trim()); if(m>=0){remaining=(m/60)+" h "+(m%60)+" min"; break;} } catch(Exception ignored){} } }
        card("CARGA ESTIMADA", percent.equals("—")?"Sin datos":percent+"%", "Lectura calculada del módulo", green);
        rowCards("AUTONOMÍA RESTANTE",estimate(rows, cols),"VOLTAJE", voltage.equals("—")?"—":voltage+" mV");
        card("DIAGNÓSTICO", rows.length>2?"Registro disponible":"Esperando muestras", "Muestras guardadas: "+Math.max(0,rows.length-1)+" · Raw: "+raw, white);
        TextView hist=text("Últimas muestras",18,white,true); LinearLayout.LayoutParams hp=params(-1,-2); hp.topMargin=dp(8); content.addView(hist,hp);
        int shown=0; for(int i=rows.length-1;i>=1 && shown<6;i--){ if(rows[i].trim().isEmpty())continue; content.addView(lineCard(rows[i])); shown++; }
        if(shown==0) content.addView(lineCard("Todavía no hay suficientes datos. Comprueba que el módulo Magisk esté activo."));
        BatteryWidgetProvider.refreshAll(this);
    }
    private String estimate(String[] rows, String[] lastCols) {
        try {
            java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US);
            f.setTimeZone(java.util.TimeZone.getDefault());
            long firstTime=-1,lastTime=-1; int firstPct=-1,lastPct=-1;
            for(int i=1;i<rows.length;i++){ String[] c=rows[i].split(","); if(c.length<6 || !c[5].trim().equals("muestra")) continue;
                long t=f.parse(c[0].trim()).getTime(); int pct=Integer.parseInt(c[1].trim());
                if(firstTime<0){firstTime=t;firstPct=pct;} lastTime=t;lastPct=pct;
            }
            if(firstTime<0 || lastTime-firstTime<1800000L || firstPct-lastPct<2 || lastPct<=0) return "Aún calculando";
            double hours=(lastTime-firstTime)/3600000.0; double rate=(firstPct-lastPct)/hours;
            if(rate<=0) return "Aún calculando";
            long mins=Math.round(lastPct/rate*60.0); return "~"+(mins/60)+" h "+(mins%60)+" min";
        } catch(Exception e){return "Aún calculando";}
    }
    private void card(String heading,String value,String detail,int valueColor){
        LinearLayout box=box(); TextView h=text(heading,11,muted,true); box.addView(h); TextView v=text(value,27,valueColor,true); LinearLayout.LayoutParams vp=params(-1,-2); vp.topMargin=dp(6); box.addView(v,vp); TextView d=text(detail,13,muted,false); LinearLayout.LayoutParams dp=params(-1,-2); dp.topMargin=dp(4); box.addView(d,dp); addCard(box);
    }
    private void rowCards(String h1,String v1,String h2,String v2){ LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL); LinearLayout a=smallCard(h1,v1), b=smallCard(h2,v2); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1); p.rightMargin=dp(6); r.addView(a,p); LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(0,-2,1); q.leftMargin=dp(6); r.addView(b,q); content.addView(r); }
    private LinearLayout smallCard(String h,String v){LinearLayout b=box(); b.addView(text(h,10,muted,true)); TextView val=text(v,18,white,true); LinearLayout.LayoutParams p=params(-1,-2); p.topMargin=dp(8); b.addView(val,p); return b;}
    private View lineCard(String s){LinearLayout b=box(); b.addView(text(s.replace(",","   ·   "),12,white,false)); return b;}
    private LinearLayout box(){LinearLayout b=new LinearLayout(this); b.setOrientation(LinearLayout.VERTICAL); b.setPadding(dp(16),dp(15),dp(16),dp(15)); b.setBackgroundColor(panel); LinearLayout.LayoutParams p=params(-1,-2); p.topMargin=dp(10); b.setLayoutParams(p); return b;}
    private void addCard(View v){content.addView(v);}
    private Button button(String s){Button b=new Button(this); b.setText(s); b.setTextColor(bg); b.setTextSize(14); b.setAllCaps(false); b.setTypeface(null,Typeface.BOLD); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(green)); return b;}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    private LinearLayout.LayoutParams params(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    private String su(String command){StringBuilder out=new StringBuilder(); try {Process p=Runtime.getRuntime().exec(new String[]{"su","-c",command}); BufferedReader r=new BufferedReader(new InputStreamReader(p.getInputStream()));String l;while((l=r.readLine())!=null)out.append(l).append('\n');p.waitFor();}catch(Exception e){return "";}return out.toString();}
    private void testNotification(){String id="xperia_battery_status"; NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE); if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel(id,"Batería Xperia",NotificationManager.IMPORTANCE_DEFAULT)); Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,id):new Notification.Builder(this); b.setSmallIcon(android.R.drawable.ic_lock_idle_low_battery).setContentTitle("Batería Xperia").setContentText("Las alertas de la aplicación funcionan correctamente.").setStyle(new Notification.BigTextStyle().bigText("Las alertas de la aplicación funcionan correctamente. El estado real depende de las mediciones y del historial disponibles.")).setAutoCancel(true); nm.notify(1201,b.build()); }
}
