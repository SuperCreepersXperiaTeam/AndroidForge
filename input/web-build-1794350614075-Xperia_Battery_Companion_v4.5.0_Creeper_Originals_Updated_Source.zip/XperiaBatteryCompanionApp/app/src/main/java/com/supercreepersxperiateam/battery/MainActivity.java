package com.supercreepersxperiateam.battery;

import android.app.*;
import android.app.usage.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private final int bg=Color.rgb(16,21,29), panel=Color.rgb(27,35,46), muted=Color.rgb(166,180,196),
        green=Color.rgb(114,214,160), white=Color.WHITE, line=Color.rgb(54,69,82);
    private LinearLayout root, content, tabs;
    private String currentTab="autonomia";
    private static final String BASE="/data/local/tmp/xperia_battery_companion";
    private static final String LOG=BASE+"/battery_log.csv";
    private static final String CONF=BASE+"/optimizer.conf";
    private static final String OPT="/data/adb/modules/xperia_battery_companion/system/bin/xperia-battery-optimizer";
    private final ArrayList<AppEntry> allApps=new ArrayList<>();

    static class AppEntry {
        String label,pkg,category,profile,lastUsed;
        Drawable icon;
        boolean system,protectedApp,lightApp;
    }

    @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);buildShell();showTab("autonomia");}
    @Override protected void onResume(){super.onResume();if(content!=null&&"apps".equals(currentTab))showApps();}

    private void buildShell(){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(bg);
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(16),dp(12),dp(16),dp(24));scroll.addView(root);
        ImageView banner=new ImageView(this);banner.setImageResource(com.supercreepersxperiateam.battery.R.drawable.creeper_channel_wallpaper);
        banner.setScaleType(ImageView.ScaleType.CENTER_CROP);banner.setBackgroundColor(bg);
        LinearLayout.LayoutParams bp=params(-1,dp(116));bp.bottomMargin=dp(10);root.addView(banner,bp);
        TextView brand=text("SUPER CREEPER'S XPERIA TEAM",12,green,true);brand.setTypeface(Typeface.MONOSPACE,Typeface.BOLD);root.addView(brand);
        TextView title=text("XPERIA BATTERY",25,white,true);title.setTypeface(Typeface.MONOSPACE,Typeface.BOLD);root.addView(title,top(params(-1,-2),dp(4)));
        root.addView(text("CREEPER ORIGINALS  ·  v4.5.0",11,muted,true),top(params(-1,-2),dp(2)));
        tabs=new LinearLayout(this);tabs.setOrientation(LinearLayout.HORIZONTAL);tabs.setBackgroundColor(panel);
        LinearLayout.LayoutParams tabp=params(-1,dp(48));tabp.topMargin=dp(14);root.addView(tabs,tabp);
        addTab("autonomia","AUTONOMÍA");addTab("perfiles","PERFILES");addTab("apps","APPS");
        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);
        root.addView(content,top(params(-1,-2),dp(10)));
        setContentView(scroll);
    }
    private void addTab(String id,String label){
        Button b=new Button(this);b.setText(label);b.setTextSize(10);b.setAllCaps(false);b.setTypeface(Typeface.MONOSPACE,Typeface.BOLD);
        b.setTextColor(white);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(panel));
        b.setOnClickListener(v->showTab(id));tabs.addView(b,new LinearLayout.LayoutParams(0,-1,1));
    }
    private void showTab(String tab){
        currentTab=tab;content.removeAllViews();
        for(int i=0;i<tabs.getChildCount();i++){
            Button b=(Button)tabs.getChildAt(i);String id=i==0?"autonomia":i==1?"perfiles":"apps";
            b.setTextColor(id.equals(tab)?green:muted);
            b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(id.equals(tab)?Color.rgb(37,57,53):panel));
        }
        if("autonomia".equals(tab))showBattery();else if("perfiles".equals(tab))showProfiles();else showApps();
    }

    private void showBattery(){
        Button refresh=button("↻  ACTUALIZAR REGISTRO");content.addView(refresh,params(-1,dp(46)));refresh.setOnClickListener(v->showBattery());
        String dump=su("cat "+LOG+" 2>/dev/null");String[] rows=dump.trim().split("\\r?\\n");
        String[] cols=rows.length>1?rows[rows.length-1].split(","):new String[0];
        String percent="—",voltage="—",raw="—";if(cols.length>=4){percent=cols[1];raw=cols[2];voltage=cols[3];}
        card("CARGA ESTIMADA",percent.equals("—")?"Sin datos":percent+"%","Lectura registrada por el módulo",green);
        rowCards("AUTONOMÍA RESTANTE",estimate(rows),"VOLTAJE BMS",voltage.equals("—")?"—":voltage+" mV");
        card("DIAGNÓSTICO",rows.length>2?"Registro disponible":"Esperando muestras","Muestras guardadas: "+Math.max(0,rows.length-1)+" · RAW: "+raw,white);
        sectionTitle("ÚLTIMAS MUESTRAS");
        int shown=0;for(int i=rows.length-1;i>=1&&shown<8;i--){if(rows[i].trim().isEmpty())continue;content.addView(lineCard(rows[i].replace(",","   ·   ")));shown++;}
        if(shown==0)content.addView(lineCard("Todavía no hay datos. Comprueba que el módulo Magisk esté activo."));
        content.addView(text("La autonomía es una estimación, no una medición de capacidad real. El módulo conserva las protecciones del BMS.",11,muted,false),top(params(-1,-2),dp(12)));
        BatteryWidgetProvider.refreshAll(this);
    }

    private void showProfiles(){
        LinearLayout section=box();sectionTitle("CONTROL DE PERFILES");
        String profile=readProfile();section.addView(text("Modo configurado: "+profileLabel(profile),21,white,true));
        String status=su("cat "+BASE+"/optimizer.status 2>/dev/null");
        String selected=valueOf(status,"selected"),effective=valueOf(status,"effective"),reason=valueOf(status,"reason");
        section.addView(text(selected.isEmpty()?"Smart Auto aún no ha publicado su estado.":"Smart Auto eligió: "+profileLabel(selected)+" · aplicado: "+profileLabel(effective)+"\\nMotivo: "+reason,12,green,false),top(params(-1,-2),dp(7)));
        section.addView(text("El módulo evalúa la pantalla, llamadas, reproducción, carga del sistema y listas de aplicaciones. Las apps desconocidas no reciben Ultra.",11,muted,false),top(params(-1,-2),dp(7)));
        addProfileButton(section,"SMART AUTO","smart","Selector automático del módulo, revisado periódicamente.");
        addProfileButton(section,"Adaptativo","adaptive","Ahorro con pantalla apagada; equilibrado al usar el teléfono.");
        addProfileButton(section,"Equilibrado","balanced","Restaura los máximos originales guardados.");
        addProfileButton(section,"Autonomía","battery","Límite de CPU del 75% si el kernel lo permite.");
        addProfileButton(section,"Ahorro extremo","ultra","Límite de CPU del 60% si el kernel lo permite.");
        addProfileButton(section,"Rendimiento","performance","Restaura el máximo original; governor solo si es compatible.");
        section.addView(text("CONFIGURACIÓN DE EXCEPCIONES",12,green,true),top(params(-1,-2),dp(16)));
        section.addView(text("La pestaña APPS permite proteger o marcar como ligera cada aplicación. Estas listas se sincronizan con el módulo.",11,muted,false),top(params(-1,-2),dp(5)));
        String diag=su("tail -n 1 "+BASE+"/optimizer.log 2>/dev/null").trim();
        section.addView(text(diag.isEmpty()?"Diagnóstico del optimizador: esperando.":"Diagnóstico: "+diag,10,muted,false),top(params(-1,-2),dp(10)));
        content.addView(section);
    }
    private void addProfileButton(LinearLayout parent,String title,String id,String detail){
        Button b=button(title+"  /  "+id);parent.addView(b,top(params(-1,dp(44)),dp(9)));
        parent.addView(text(detail,10,muted,false),top(params(-1,-2),dp(3)));
        b.setOnClickListener(v->{String cmd="OPT="+OPT+"; [ -x \\"$OPT\\" ] || OPT=/data/adb/modules_update/xperia_battery_companion/system/bin/xperia-battery-optimizer; [ -x \\"$OPT\\" ] || { echo PROFILE_ERROR_NO_MODULE; exit 3; }; \\"$OPT\\" set "+id+" && \\"$OPT\\" apply && echo PROFILE_APPLIED";
            String result=su(cmd);Toast.makeText(this,result.contains("PROFILE_APPLIED")?"Perfil "+title+" aplicado":"No se pudo aplicar. Comprueba root y el módulo.",Toast.LENGTH_LONG).show();showProfiles();});
    }

    private void showApps(){
        sectionTitle("CATÁLOGO DE APLICACIONES");
        boolean usage=hasUsageAccess();
        LinearLayout info=box();
        info.addView(text(usage?"ESTADÍSTICAS DE USO: ACTIVADAS":"ESTADÍSTICAS DE USO: FALTA AUTORIZACIÓN",12,usage?green:Color.rgb(255,190,100),true));
        info.addView(text(usage?"Android permite consultar el uso reciente. La categoría se obtiene de metadatos del sistema y reglas conservadoras.":"Concede el acceso especial para consultar actividad reciente. La lista de apps puede mostrarse igualmente sin este permiso.",11,muted,false),top(params(-1,-2),dp(5)));
        if(!usage){Button grant=button("CONCEDER ACCESO A DATOS DE USO");info.addView(grant,top(params(-1,dp(44)),dp(8)));grant.setOnClickListener(v->{try{startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));}catch(Exception e){Toast.makeText(this,"No se pudo abrir el ajuste de Android.",Toast.LENGTH_LONG).show();}});}
        content.addView(info);
        Button reload=button("↻  ACTUALIZAR LISTA");content.addView(reload,top(params(-1,dp(44)),dp(8)));reload.setOnClickListener(v->showApps());
        loadApps(usage);
        TextView count=text(allApps.size()+" aplicaciones detectadas · orden alfabético",11,muted,false);content.addView(count,top(params(-1,-2),dp(10)));
        EditText search=new EditText(this);search.setSingleLine(true);search.setTextColor(white);search.setHintTextColor(muted);search.setHint("Buscar aplicación o paquete…");search.setTextSize(13);
        content.addView(search,top(params(-1,dp(48)),dp(6)));
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);content.addView(list,top(params(-1,-2),dp(5)));
        Runnable render=()->{list.removeAllViews();String q=search.getText().toString().toLowerCase(Locale.ROOT);int shown=0;
            for(AppEntry a:allApps){if(!a.label.toLowerCase(Locale.ROOT).contains(q)&&!a.pkg.toLowerCase(Locale.ROOT).contains(q))continue;list.addView(appCard(a));shown++;}
            if(shown==0)list.addView(lineCard("No hay aplicaciones que coincidan con la búsqueda."));
        };
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){render.run();}public void afterTextChanged(android.text.Editable e){}});
        render.run();
    }
    private void loadApps(boolean usage){
        allApps.clear();Set<String> protectedSet=csvSet(su("cat "+BASE+"/protected_apps.conf 2>/dev/null"));
        Set<String> lightSet=csvSet(su("cat "+BASE+"/light_apps.conf 2>/dev/null"));
        Map<String,Long> last=new HashMap<>();
        if(usage){try{UsageStatsManager us=(UsageStatsManager)getSystemService(USAGE_STATS_SERVICE);long now=System.currentTimeMillis();
            List<UsageStats> stats=us.queryUsageStats(UsageStatsManager.INTERVAL_DAILY,now-7L*24*60*60*1000,now);
            if(stats!=null)for(UsageStats x:stats){Long old=last.get(x.getPackageName());if(old==null||x.getLastTimeUsed()>old)last.put(x.getPackageName(),x.getLastTimeUsed());}
        }catch(Exception ignored){}}
        PackageManager pm=getPackageManager();List<ApplicationInfo> installed;
        try{installed=pm.getInstalledApplications(PackageManager.GET_META_DATA);}catch(Exception e){installed=new ArrayList<>();}
        for(ApplicationInfo ai:installed){
            try{
                AppEntry a=new AppEntry();a.pkg=ai.packageName;a.label=pm.getApplicationLabel(ai).toString();a.icon=pm.getApplicationIcon(ai);
                a.system=(ai.flags&ApplicationInfo.FLAG_SYSTEM)!=0;a.protectedApp=protectedSet.contains(a.pkg);a.lightApp=lightSet.contains(a.pkg);
                a.category=categoryName(ai);a.profile=profileFor(a);
                long t=last.containsKey(a.pkg)?last.get(a.pkg):0;a.lastUsed=t==0?"Sin dato":new SimpleDateFormat("dd/MM HH:mm",Locale.getDefault()).format(new Date(t));
                allApps.add(a);
            }catch(Exception ignored){}
        }
        Collections.sort(allApps,(a,b)->a.label.compareToIgnoreCase(b.label));
    }
    private String categoryName(ApplicationInfo ai){
        if(Build.VERSION.SDK_INT>=26){switch(ai.category){
            case ApplicationInfo.CATEGORY_GAME:return "Juegos";case ApplicationInfo.CATEGORY_AUDIO:return "Audio";
            case ApplicationInfo.CATEGORY_VIDEO:return "Vídeo";case ApplicationInfo.CATEGORY_IMAGE:return "Fotografía";
            case ApplicationInfo.CATEGORY_SOCIAL:return "Redes sociales";case ApplicationInfo.CATEGORY_NEWS:return "Noticias";
            case ApplicationInfo.CATEGORY_MAPS:return "Mapas";case ApplicationInfo.CATEGORY_PRODUCTIVITY:return "Productividad";
            case ApplicationInfo.CATEGORY_ACCESSIBILITY:return "Accesibilidad";}}
        String p=ai.packageName.toLowerCase(Locale.ROOT);
        if(p.contains("launcher")||p.contains("settings")||p.contains("systemui"))return "Sistema";
        if(p.contains("camera")||p.contains("gallery")||p.contains("photo"))return "Fotografía";
        if(p.contains("music")||p.contains("audio")||p.contains("spotify")||p.contains("youtube"))return "Multimedia";
        if(p.contains("editor")||p.contains("inshot")||p.contains("capcut"))return "Edición";
        if(p.contains("messag")||p.contains("whatsapp")||p.contains("telegram")||p.contains("discord"))return "Comunicación";
        return "Sin clasificar";
    }
    private String profileFor(AppEntry a){
        if(a.protectedApp)return "Balanced";
        if(a.lightApp)return "Battery*";
        if(a.category.equals("Juegos")||a.category.equals("Edición")||a.category.equals("Multimedia")||a.category.equals("Redes sociales")||a.category.equals("Comunicación"))return "Adaptive";
        if(a.system)return "Adaptive";
        if(a.category.equals("Sistema")||a.category.equals("Productividad")||a.category.equals("Accesibilidad"))return "Battery*";
        return "Adaptive · seguro";
    }
    private View appCard(AppEntry a){
        LinearLayout card=box();LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);
        ImageView icon=new ImageView(this);icon.setImageDrawable(a.icon);row.addView(icon,new LinearLayout.LayoutParams(dp(42),dp(42)));
        LinearLayout names=new LinearLayout(this);names.setOrientation(LinearLayout.VERTICAL);names.setPadding(dp(10),0,0,0);
        names.addView(text(a.label,14,white,true));names.addView(text(a.pkg,9,muted,false));row.addView(names,new LinearLayout.LayoutParams(0,-2,1));card.addView(row);
        card.addView(text("Categoría: "+a.category+"   ·   Último uso: "+a.lastUsed,10,muted,false),top(params(-1,-2),dp(7)));
        TextView prof=text("Se aplicará: "+a.profile+(a.system?"  ·  Sistema":""),12,green,true);card.addView(prof,top(params(-1,-2),dp(4)));
        LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);
        Button protect=smallButton(a.protectedApp?"QUITAR PROTECCIÓN":"PROTEGER");
        Button light=smallButton(a.lightApp?"QUITAR LIGERA":"MARCAR LIGERA");
        actions.addView(protect,new LinearLayout.LayoutParams(0,dp(38),1));actions.addView(light,new LinearLayout.LayoutParams(0,dp(38),1));card.addView(actions,top(params(-1,-2),dp(7)));
        protect.setOnClickListener(v->{Set<String>s=csvSet(su("cat "+BASE+"/protected_apps.conf 2>/dev/null"));if(a.protectedApp)s.remove(a.pkg);else s.add(a.pkg);saveList("protect",s);showApps();});
        light.setOnClickListener(v->{Set<String>s=csvSet(su("cat "+BASE+"/light_apps.conf 2>/dev/null"));if(a.lightApp)s.remove(a.pkg);else s.add(a.pkg);saveList("light",s);showApps();});
        return card;
    }
    private void saveList(String type,Set<String> set){
        StringBuilder b=new StringBuilder();for(String p:set){if(!p.matches("[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)*"))continue;if(b.length()>0)b.append(",");b.append(p);}
        String cmd="OPT="+OPT+"; [ -x \\"$OPT\\" ] || OPT=/data/adb/modules_update/xperia_battery_companion/system/bin/xperia-battery-optimizer; [ -x \\"$OPT\\" ] && \\"$OPT\\" "+type+" '"+b+"' && echo SAVED";
        String r=su(cmd);Toast.makeText(this,r.contains("SAVED")?"Lista sincronizada con el módulo":"No se pudo sincronizar. Concede root y comprueba el módulo.",Toast.LENGTH_LONG).show();
    }
    private Set<String> csvSet(String s){Set<String> out=new LinkedHashSet<>();for(String x:s.replace("\\n","").split(",")){x=x.trim();if(!x.isEmpty())out.add(x);}return out;}
    private boolean hasUsageAccess(){
        try{AppOpsManager a=(AppOpsManager)getSystemService(APP_OPS_SERVICE);int mode;
            if(Build.VERSION.SDK_INT>=29)mode=a.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,android.os.Process.myUid(),getPackageName());
            else mode=a.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,android.os.Process.myUid(),getPackageName());
            return mode==AppOpsManager.MODE_ALLOWED;
        }catch(Exception e){return false;}
    }

    private String readProfile(){String p=su("cat "+CONF+" 2>/dev/null").trim();return Arrays.asList("smart","adaptive","balanced","battery","ultra","performance").contains(p)?p:"adaptive";}
    private String profileLabel(String p){switch(p){case "smart":return "Smart Auto";case "balanced":return "Equilibrado";case "battery":return "Autonomía";case "ultra":return "Ahorro extremo";case "performance":return "Rendimiento";default:return "Adaptativo";}}
    private String valueOf(String s,String k){for(String l:s.split("\\r?\\n"))if(l.startsWith(k+"="))return l.substring(k.length()+1).trim();return "";}
    private void sectionTitle(String s){content.addView(text(s,13,green,true),top(params(-1,-2),dp(8)));}
    private String estimate(String[] rows){try{SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US);f.setLenient(false);ArrayList<long[]> a=new ArrayList<>();
        for(int i=1;i<rows.length;i++){String[] c=rows[i].split(",");if(c.length<6||!c[5].trim().equals("muestra"))continue;long t=f.parse(c[0].trim()).getTime();int p=Integer.parseInt(c[1].trim());if(p<1||p>100)continue;if(!a.isEmpty()&&t<=a.get(a.size()-1)[0])continue;a.add(new long[]{t,p});}
        if(a.size()<2)return "Aún calculando";long[] last=a.get(a.size()-1);int first=a.size()-1;while(first>0&&last[0]-a.get(first-1)[0]<=900000)first--;long[] start=a.get(first);long elapsed=last[0]-start[0];int drop=(int)(start[1]-last[1]);if(elapsed<1800000||drop<2||last[1]<=0)return "Aún calculando";double rate=drop/(elapsed/3600000.0);if(rate<=0||rate>10)return "Estimación inestable";long mins=Math.round(last[1]/rate*60);if(mins>10080)return "Estimación inestable";return "~"+(mins/60)+" h "+(mins%60)+" min";
        }catch(Exception e){return "Aún calculando";}}
    private void card(String h,String v,String d,int c){LinearLayout b=box();b.addView(text(h,11,muted,true));b.addView(text(v,27,c,true),top(params(-1,-2),dp(6)));b.addView(text(d,12,muted,false),top(params(-1,-2),dp(4)));content.addView(b);}
    private void rowCards(String h1,String v1,String h2,String v2){LinearLayout r=new LinearLayout(this);LinearLayout a=smallCard(h1,v1),b=smallCard(h2,v2);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.rightMargin=dp(5);r.addView(a,p);LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(0,-2,1);q.leftMargin=dp(5);r.addView(b,q);content.addView(r);}
    private LinearLayout smallCard(String h,String v){LinearLayout b=box();b.addView(text(h,10,muted,true));b.addView(text(v,17,white,true),top(params(-1,-2),dp(7)));return b;}
    private View lineCard(String s){LinearLayout b=box();b.addView(text(s,11,white,false));return b;}
    private LinearLayout box(){LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);b.setPadding(dp(13),dp(13),dp(13),dp(13));b.setBackgroundColor(panel);LinearLayout.LayoutParams p=params(-1,-2);p.topMargin=dp(8);b.setLayoutParams(p);return b;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(bg);b.setTextSize(12);b.setAllCaps(false);b.setTypeface(Typeface.MONOSPACE,Typeface.BOLD);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(green));return b;}
    private Button smallButton(String s){Button b=button(s);b.setTextSize(9);b.setPadding(dp(2),0,dp(2),0);return b;}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.MONOSPACE,Typeface.BOLD);return t;}
    private LinearLayout.LayoutParams params(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int m){p.topMargin=m;return p;}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    private String su(String command){StringBuilder out=new StringBuilder();try{Process p=Runtime.getRuntime().exec(new String[]{"su","-c",command});BufferedReader r=new BufferedReader(new InputStreamReader(p.getInputStream()));String l;while((l=r.readLine())!=null)out.append(l).append('\n');p.waitFor();}catch(Exception e){return "";}return out.toString();}
}
