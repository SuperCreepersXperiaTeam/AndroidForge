# Xperia Battery Companion 4.5.0 — Creeper Originals (revisión final)

Autor: SuperCreeper'sXperiaTeam. La versión visible permanece **4.5.0** para conservar la descripción de GitHub aún no publicada. `versionCode` interno: 451.

## Cambios
- Tres pestañas separadas: Autonomía, Perfiles y Apps.
- Ilustración original del canal como banner de identidad.
- Tipografía monoespaciada de estilo técnico/pixel como alternativa integrada sin fuentes externas.
- Catálogo local de aplicaciones instaladas, con búsqueda, paquete, categoría detectada, último uso cuando Usage Access está autorizado y perfil recomendado.
- Solicitud del acceso especial `PACKAGE_USAGE_STATS` desde la pestaña Apps.
- Excepciones por aplicación: Proteger (Balanced) y Marcar ligera (Battery condicionado a baja carga); sincronización con `xperia-battery-optimizer protect/light`.
- Conserva la pantalla de autonomía, estimación, historial CSV, perfiles y widget existentes.

## Limitaciones importantes
- La lista usa categorías de Android cuando están disponibles y reglas heurísticas para el resto; no puede garantizar categorías correctas para todas las apps.
- La columna "Se aplicará" es una recomendación basada en categoría/listas. El módulo 4.5.0 decide el perfil efectivo con sus reglas propias (pantalla, llamada, reproducción, carga y foreground package). La clasificación de la app no sustituye ni reprograma el selector interno del módulo.
- Las apps marcadas como ligeras se aplican como candidatas a `battery` únicamente cuando el módulo detecta baja carga. Las protegidas se fuerzan a `balanced`.
- El permiso de uso es especial: Android abre Ajustes > Acceso a datos de uso y el usuario debe activarlo manualmente.
- `QUERY_ALL_PACKAGES` se usa porque la función solicitada requiere mostrar el inventario completo en una app instalada por sideload. Puede estar sujeto a restricciones de distribución de Google Play.
- La tipografía monoespaciada es un sustituto visual; no se incluye una fuente Minecraft licenciada ni se afirma que sea la fuente oficial.

## Compilar
Abrir el proyecto en Android Studio con JDK 17 y Android SDK 34. La carpeta no incluye Gradle Wrapper. Sin Android SDK/Gradle en el entorno de edición no se entrega un APK compilado ni se afirma que haya sido probado en el Xperia. Compilar con Build > Build APK(s).
